var execed = "some-executed-string";
